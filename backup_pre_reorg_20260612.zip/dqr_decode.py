"""
dqr_decode.py — D_QR 디코더 CLI (이미지 파일만으로 디코딩)
사용: py -X utf8 dqr_decode.py 이미지경로.png

PNG 파일에 내장된 메타데이터를 읽어 추가 파라미터 없이 디코딩.
  exp9 → soft-decision 소거 복호 (decoder_v9)
  exp6 → hard decision (decoder_v6, 구버전 호환)
"""
import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from PIL import Image


def decode(image_path: str, threshold: int = 128):
    img = Image.open(image_path)
    meta = img.info  # PNG tEXt 메타데이터

    # ── 필수 파라미터 확인 ───────────────────────────────────────────
    required = ["dqr_version", "dqr_radius", "dqr_hex_size",
                "dqr_origin_x", "dqr_origin_y",
                "dqr_nsym", "dqr_data_len", "dqr_codeword_len"]

    missing = [k for k in required if k not in meta]
    if missing:
        print(f"[오류] PNG 메타데이터에 D_QR 파라미터가 없음: {missing}")
        print("       dqr_encode.py로 인코딩한 파일이 맞는지 확인하세요.")
        sys.exit(1)

    version      = meta["dqr_version"]
    radius       = int(meta["dqr_radius"])
    hex_size     = float(meta["dqr_hex_size"])
    origin_x     = float(meta["dqr_origin_x"])
    origin_y     = float(meta["dqr_origin_y"])
    nsym         = int(meta["dqr_nsym"])
    data_len     = int(meta["dqr_data_len"])
    codeword_len = int(meta["dqr_codeword_len"])

    print(f"[메타데이터 읽기 완료]")
    print(f"  버전         : {version}")
    print(f"  격자 반지름  : r={radius}")
    print(f"  hex_size     : {hex_size}px")
    print(f"  nsym         : {nsym}")
    print(f"  data_len     : {data_len} bytes")
    print(f"  이미지 크기  : {img.width} × {img.height} px")

    # ── 버전별 디코딩 ───────────────────────────────────────────────
    if version == "exp9":
        from src.decoder_v9 import DQRDecoderV9
        profile = meta.get("dqr_profile", "A")
        bits_per_cell = int(meta.get("dqr_bits_per_cell", "6"))
        print(f"  프로파일     : {profile} ({bits_per_cell}비트/셀)")
        print()

        dec = DQRDecoderV9(threshold=threshold)
        stats = dec.decode_with_stats(
            img,
            radius=radius,
            hex_size=hex_size,
            bits_per_cell=bits_per_cell,
            origin_x=origin_x,
            origin_y=origin_y,
            nsym=nsym,
            data_len=data_len,
            codeword_len=codeword_len,
        )
        raw = stats['data']
        print(f"[복호 통계] 모드={stats['mode']}, 소거={stats['erasures_used']}, "
              f"정정={stats['errata_count']}바이트")
    else:
        from src.decoder_v6 import DQRDecoderV6
        print()
        dec = DQRDecoderV6(threshold=threshold)
        raw = dec.decode(
            img,
            radius=radius,
            hex_size=hex_size,
            origin_x=origin_x,
            origin_y=origin_y,
            nsym=nsym,
            data_len=data_len,
            codeword_len=codeword_len,
        )

    text = raw.decode("utf-8")
    print(f"[디코딩 결과]")
    print(f"  {text}")
    return text


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="D_QR 디코더 (이미지만으로 디코딩)")
    parser.add_argument("image", help="D_QR PNG 이미지 경로")
    parser.add_argument("--threshold", type=int, default=128,
                        help="밝기 임계값 (기본: 128)")
    args = parser.parse_args()

    decode(args.image, args.threshold)

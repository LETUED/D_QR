"""
dqr_encode.py — D_QR 인코더 CLI (exp9 가변 프로파일)
사용: py -X utf8 dqr_encode.py "인코딩할 텍스트" [-o 출력경로.png] [--profile A|B]

  프로파일 A: 6비트/셀,  ECC 30% — 인쇄·실외 (인식률 우선, 기본)
  프로파일 B: 12비트/셀, ECC 20% — 화면·근접 (밀도 우선)

모든 디코딩 파라미터를 PNG tEXt 메타데이터에 내장 → 이미지 파일만으로 디코딩 가능.
"""
import sys
import os
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from PIL import PngImagePlugin
from src.encoder_v9 import DQREncoderV9, PROFILES
from src.renderer_v9 import DQRRendererV9


def encode(text: str, output_path: str, profile: str = "A",
           ecc_rate: float = None, hex_size: int = 32):
    data = text.encode("utf-8")

    enc = DQREncoderV9(profile=profile, ecc_rate=ecc_rate)
    ren = DQRRendererV9(hex_size=hex_size)

    result = enc.encode(data)
    img, render_info = ren.render(result)

    # ── 디코딩에 필요한 모든 파라미터를 PNG 메타데이터에 내장 ──────
    meta = PngImagePlugin.PngInfo()
    meta.add_text("dqr_version",       "exp9")
    meta.add_text("dqr_profile",       result['profile'])
    meta.add_text("dqr_bits_per_cell", str(result['bits_per_cell']))
    meta.add_text("dqr_radius",        str(result['radius']))
    meta.add_text("dqr_hex_size",      str(render_info['hex_size']))
    meta.add_text("dqr_origin_x",      str(render_info['origin_x']))
    meta.add_text("dqr_origin_y",      str(render_info['origin_y']))
    meta.add_text("dqr_nsym",          str(result['nsym']))
    meta.add_text("dqr_data_len",      str(result['data_len']))
    meta.add_text("dqr_codeword_len",  str(result['codeword_len']))

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    img.save(output_path, pnginfo=meta)

    cap = result['capacity']
    print(f"[인코딩 완료]")
    print(f"  입력 텍스트  : {text}")
    print(f"  바이트 크기  : {len(data)} bytes")
    print(f"  프로파일     : {result['profile']} ({PROFILES[result['profile']]['desc']})")
    print(f"  비트/셀      : {result['bits_per_cell']}")
    print(f"  격자 반지름  : r={result['radius']}  ({cap['total_cells']} 셀)")
    print(f"  ECC          : {cap['ecc_rate']*100:.0f}%  (nsym={result['nsym']})")
    print(f"  이미지 크기  : {img.width} × {img.height} px")
    print(f"  저장 경로    : {output_path}")
    print(f"  (PNG 메타데이터에 디코딩 파라미터 내장 완료)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="D_QR 인코더 (exp9)")
    parser.add_argument("text", help="인코딩할 텍스트")
    parser.add_argument("-o", "--output", default="outputs/dqr_encoded.png",
                        help="출력 PNG 경로 (기본: outputs/dqr_encoded.png)")
    parser.add_argument("--profile", choices=list(PROFILES), default="A",
                        help="A=인쇄·실외(인식률), B=화면·근접(밀도) (기본: A)")
    parser.add_argument("--ecc", type=float, default=None,
                        help="ECC rate 수동 지정 (기본: 프로파일 기본값)")
    parser.add_argument("--hex-size", type=int, default=32, help="헥사곤 크기 px (기본: 32)")
    args = parser.parse_args()

    encode(args.text, args.output, args.profile, args.ecc, args.hex_size)
